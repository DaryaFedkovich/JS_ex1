var a1 = 5 % 3,
	a2 = 3 % 5,
	a3 = 5 % '3',
	a4 = '5' % 3,
	a5 = 75 + 'кг',
	a6 = 785 * 653,
	a7 = 100 /25,
	a8 = 0 * 0,
	a9 = 0 / 2,
	a10 = 89 / 0,
	a11 = 98 + 2,
	a12 = 5 - 98,
	a13 = (8 + 56 * 4) / 5,
	a14 = (9 - 12) * 7 / (5 + 2),
	a15 = +"123",
	a16 = 1 || 0,
	a17 = false || true,
	a18 = true > 0;
	console.log(a1);
	console.log(a2);
	console.log(a3);
	console.log(a4);
	console.log(a5);
	console.log(a6);
	console.log(a7);
	console.log(a8);
	console.log(a9);
	console.log(a10);
	console.log(a11);
	console.log(a12);
	console.log(a13);
	console.log(a14);
	console.log(a15);
	console.log(a16);
	console.log(a17);
	console.log(a18);
	console.log(typeof a1);
	console.log(typeof a2);
	console.log(typeof a3);
	console.log(typeof a4);
	console.log(typeof a5);
	console.log(typeof a6);
	console.log(typeof a7);
	console.log(typeof a8);
	console.log(typeof a9);
	console.log(typeof a10);
	console.log(typeof a11);
	console.log(typeof a12);
	console.log(typeof a13);
	console.log(typeof a14);
	console.log(typeof a15);
	console.log(typeof a16);
	console.log(typeof a17);
	console.log(typeof a18);

