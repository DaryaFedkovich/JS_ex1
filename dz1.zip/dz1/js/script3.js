var height = 23,
	width = 10;
var SPryam = height * width;
console.log(SPryam);
