var height = 10,
	R = a7 / 2;

var VCilindra = height * R * R * Math.PI;
console.log(VCilindra);