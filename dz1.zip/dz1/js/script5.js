var r = 5,
	SKruga = Math.PI * r * r;
console.log(SKruga);