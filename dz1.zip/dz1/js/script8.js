var a = 8,
	b = 3,
	x,
	p = 16,
	k = 23780;
x = (p - a + 2 * b) / 2;
console.log(x);

x = a / (b + 9);
console.log(x);

x = k / (1 + 2 + a + b);
console.log(x);