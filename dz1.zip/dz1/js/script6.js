var a = 5,
	b = 7,
	h = 10,
	STrap = ((a + b) / 2) * h;
console.log(STrap);
